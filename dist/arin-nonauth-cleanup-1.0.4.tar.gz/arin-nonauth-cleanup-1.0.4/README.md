ARIN-NONAUTH Cleanup Analyser
=====================================

A simple tool to show what ARIN-NONAUTH objects are affected by
RPKI ROAs.

Installation
------------

`pip3 install arin-nonauth-cleanup`

Use
---

`$ arin-nonauth-cleanup`

Copyright
---------

Copyright (c) 2019 Job Snijders <job@ntt.net>
